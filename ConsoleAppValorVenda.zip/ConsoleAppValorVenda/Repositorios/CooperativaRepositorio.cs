﻿namespace ConsoleAppValorVenda
{
    public static class CooperativaRepositorio
    {
        public static Cooperativa[] Cooperativas =
        {
            new Cooperativa(1, "Campo Mourao", MunicipioRepositorio.Municipios[0]),
        };
    }
}