﻿namespace ConsoleAppValorVenda
{
    public static class GrupoRepositorio
    {
        public static Grupo[] Grupos =
        {
            new Grupo(1, "Fertilizantes"),
            new Grupo(2, "Corretivos"),
            new Grupo(3, "Herbicidas"),
            new Grupo(4, "Fungicidas"),
            new Grupo(5, "Inseticidas")
        };
    }
}