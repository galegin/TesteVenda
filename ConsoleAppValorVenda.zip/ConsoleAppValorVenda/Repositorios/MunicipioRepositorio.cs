﻿namespace ConsoleAppValorVenda
{
    public static class MunicipioRepositorio
    {
        public static Municipio[] Municipios =
        {
            new Municipio(1, "Campo Mourao", "PR"),
            new Municipio(2, "Florianopolis", "SC"),
            new Municipio(3, "Campo Grande", "MS"),
        };
    }
}