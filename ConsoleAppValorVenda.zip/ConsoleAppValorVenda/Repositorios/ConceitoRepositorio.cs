﻿namespace ConsoleAppValorVenda
{
    public static class ConceitoRepositorio
    {
        public static Conceito[] Conceitos =
        {
            new Conceito(ConceitoTipo.A, 5.0),
            new Conceito(ConceitoTipo.B, 3.0),
            new Conceito(ConceitoTipo.C, 0.0),
        };
    }
}