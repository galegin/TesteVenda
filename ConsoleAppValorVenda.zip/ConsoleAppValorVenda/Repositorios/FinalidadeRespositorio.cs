﻿namespace ConsoleAppValorVenda
{
    public static class FinalidadeRespositorio
    {
        public static Finalidade[] Finalidades =
        {
            new Finalidade(1, "Venda")
        };
    }
}