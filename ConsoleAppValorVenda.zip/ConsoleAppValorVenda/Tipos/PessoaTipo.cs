﻿namespace ConsoleAppValorVenda
{
    public enum PessoaTipo
    {
        Fisica,
        Juridica,
    }
}