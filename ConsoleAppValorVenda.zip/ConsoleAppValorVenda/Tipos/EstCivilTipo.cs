﻿namespace ConsoleAppValorVenda
{
    public enum EstCivilTipo
    {
        Solteiro,
        Casado,
        Viuvo,
        Outros
    }
}