﻿namespace ConsoleAppValorVenda
{
    public enum ConceitoTipo
    {
        A,
        B,
        C
    }
}